package org.railroad;

public record TrackPair(int inbound, int outbound) {
}